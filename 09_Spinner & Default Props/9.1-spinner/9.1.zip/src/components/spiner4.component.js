import React from 'react'
import './spiners.css'

const Spiner4 = () => {
  return (
    <div className="three-dots" id="three-dots2">
      <div className="dot"></div>
      <div className="dot"></div>
      <div className="dot"></div>
    </div>
  )
}

export default Spiner4;