import React from 'react'
import './spiners.css'

const Spiner3 = () => {
  return (
    <div className="three-dots" id="three-dots1">
      <div className="dot"></div>
      <div className="dot"></div>
      <div className="dot"></div>
    </div>
  )
}

export default Spiner3;