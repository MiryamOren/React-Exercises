import React from 'react'
import './spiners.css'

const Spiner2 = () => {
  return <div className="circle circle2"></div>
}

export default Spiner2;