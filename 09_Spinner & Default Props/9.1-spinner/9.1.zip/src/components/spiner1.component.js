import React from 'react'
import './spiners.css'

const Spiner1 = () => {
  return <div className="circle circle1"></div>
}

export default Spiner1;